<?php
//1. Leggo i dati in arrivo dal client
$movimenti = json_encode($_POST['fromClient']);

//2. Li salvo in un file
file_put_contents("movimenti.txt", $movimenti);

//3. Rispondo al client
echo 'OK';
?>