$(document).ready(()=>{
    $("#btnAdd").click(addMovement)
})

function addMovement(){
    if(!validateInput()){
        alert("Riempire tutti i campi!")
        return
    }

    //salvo i valori dell'utente
    let date = $("#inDate").val()
    let cause = $("#inCause").val() 
    let value = parseFloat($("#inValue").val()) //converto in decimale

    //svuoto le caselle di testo
    $("input").val("") //.clear()

    /*
    <div class="movement income">
        <div class="oldDate">10/08/2026</div>
        <div class="oldCause">Fest</div>
        <div class="oldValue">€ 10.56</div>
        <div class="oldButtons">
            <button type="button" class="editBtn" onclick="editMov">e</button>            
            <button type="button" class="editBtn" onclick="deleteMov">d</button>
        </div>
    </div>
    */
    let divMov = $("<div></div>") //creo un div
    $(divMov).addClass("movement") //aggiungo la classe movement

    if(value>=0){
        $(divMov).addClass("income")
    }else{
        $(divMov).addClass("outcome")
    }

    //$(divMov).addClass((value>=0)?"income":"outcome") IF IN-LINE
    let divDate = $("<div></div>")
    let divCause = $("<div></div>")
    let divValue = $("<div></div>")

    $(divDate).addClass("oldDate")
    $(divCause).addClass("oldCause")
    $(divValue).addClass("oldValue")

    var dataItaliana = new Date(date).toLocaleDateString('it-IT'); //Trasformo data in formato italiano

    $(divDate).text(dataItaliana)
    $(divCause).text(cause)
    $(divValue).text("€ " + value.toFixed(2)) //Aggiungo i decimali al valore


    //Creo ANCHE il div per i bottoni
    let divBtn = $("<div></div>")
    $(divBtn).addClass("oldButtons")

    let editBtn = $('<button type="button" class="editBtn" onclick="editMov(this)"><span class="material-symbols-outlined">edit</span></button>')
    let deleteBtn = $('<button type="button" class="editBtn" onclick="deleteMov(this)"><span class="material-symbols-outlined">delete</span></button>')

    $(divBtn).append(editBtn, deleteBtn)

    //aggiungo i div FIGLI al loro PADRE
    $(divMov).append(divDate, divCause, divValue, divBtn)

    //aggiungo al container
    $("#container").append(divMov)
    updateBalance()
}

function validateInput(){
    if( $("#inDate").val() == "" ){
        return false
    }

    if( $("#inCause").val() == ""){
        return false
    }

    if( $("#inValue").val() == ""){
        return false
    }

    return true
}

function updateBalance() {
    //Facciamo un ciclo con tag di classe oldValue e gli sommiamo fra di loro
    let total = 0;
    
    $(".oldValue").each((idx,value)=>{ //al posto di un ciclo for questa funzione capisce quanti elementi deve iterare
        text = $(value).text()
        money = parseFloat(text.split(" ")[1])
        total += money
    })  
    $("#amount").text("€ " + total.toFixed(2))

    storeData()
}

/*
SFIDA 1: all'avvio, il saldo iniziale deve essere zero

SFIDA 2: colorare il saldo di verde/rosso ad ogni aggiornamento

SFIDA 3(css): posizionare il saldo sempre in fondo alla pagina

*/

//salvo i dati sul server
function storeData(){

    let movementList = [];

    $(".movement").each((idx, tag)=>{ //funzione anonima del for-each
        //1. estraggo dai <div> figli di questo elemento
        //i 3 valori necessari
        let data = $(tag).find(".oldDate").text()
        let cause = $(tag).find(".oldCause").text()
        let money = $(tag).find(".oldValue").text().split(" ")[1]

        //2. Creo un dizionario con i 3 valori estratti
        let dictionary = {
            oldDate: data,
            oldCause: cause,
            oldValue: money
        }

        //3. Aggiungo il dizionario alla lista dei movimenti
        movementList.push(dictionary)
    })

    //AJAX (contattare il server in asincrono)
    $.ajax({
        method: 'POST',
        url: 'saveMovement.php',
        data: {
            fromClient: movementList
        }
    }).done((response)=>{ //funzione chiamata se il server risponde
        if(response == 'OK'){
            alert("Dati salvati con successo!")
        }else{
            alert("Problemi nel salvataggio")
        }
    }).fail((error)=>{//funzione chiamata se il server non risponde
        alert("Errore nel server")
        console.log(error)
    })
}

function deleteMov(btn){
    //1. risalgo al nonno del bottone (btn è il bottone premuto)
    let movimento = $(btn).parent().parent()

    //2. rimuovo l'intero movimento
    $(movimento).remove()

    //3. aggiorno il saldo finale
    updateBalance()
}